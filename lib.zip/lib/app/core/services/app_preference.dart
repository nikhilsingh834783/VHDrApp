class AppPreferencesHelper {
  static const userData = 'UserData';
  static const token = 'Token';
  static const getGlobalConfig = 'GetGlobalConfig';
  static const isBiometricEnable = 'IsBiometricEnable';
  static const isEditProfile = 'isEditProfile';
  static const refreshToken = 'token';
  static const isNotificationAllow = 'isNotificationAllow';
}
