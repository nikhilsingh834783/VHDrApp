import 'package:get_storage/get_storage.dart';

class Utils {
  static GetStorage getStorage = GetStorage();
  static DateTime? servertime;
  static bool isTestMode = false;
}
