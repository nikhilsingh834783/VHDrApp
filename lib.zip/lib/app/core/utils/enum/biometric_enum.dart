enum SupportState {
  unknown,
  supported,
  unsupported,
}
