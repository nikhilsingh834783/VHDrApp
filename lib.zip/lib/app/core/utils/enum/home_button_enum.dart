enum HomeSelectedButtonType { timeData, calculatedData,payOut,total }
