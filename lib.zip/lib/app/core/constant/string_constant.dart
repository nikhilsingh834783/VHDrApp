class ConstString {
  //---intro----
}
