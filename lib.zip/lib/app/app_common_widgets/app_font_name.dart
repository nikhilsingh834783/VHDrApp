class CommonFontStyle {
  static String plusJakartaSans = "PlusJakartaSans";
}
